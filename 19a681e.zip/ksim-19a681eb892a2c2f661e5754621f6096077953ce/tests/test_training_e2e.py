"""Tests for training examples in the ksim package."""

import pytest


@pytest.mark.slow
@pytest.mark.skip(reason="This test doesn't work yet")
def test_default_humanoid_training() -> None:
    raise NotImplementedError("This test doesn't work yet")


if __name__ == "__main__":
    test_default_humanoid_training()
